-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 16, 2022 at 05:30 AM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 7.4.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sales3`
--

--
-- Dumping data for table `statuses`
--

INSERT INTO `statuses` (`id`, `nama`, `tabel`, `detail`, `created_at`, `updated_at`, `order`) VALUES
(1, 'trip', 'trips', 'adalah status yang hanya melakukan kunjungan dan tidak melakukan order', NULL, NULL, 1),
(2, 'order', 'trips', 'adalah status yang melakukan kunjungan dan order dengan nama lain effective call', NULL, NULL, 2),
(3, 'active', 'customers', 'customer masih beroperasi sebagai penjual atau pembeli yang aktif', NULL, NULL, 1),
(4, 'inactive', 'customers', 'customer sudah tidak pernah aktif lagi sebagai penjual ( toko tidak berjualan lagi, toko dianggap tidak mampu melakukan pembelian lagi )', NULL, NULL, -1),
(5, 'disetujui', 'customerslimit', 'pengajuan limit customer terakhir disetujui oleh supervisor ( merubah limit pembelian sama dengan pengajuan limit pembelian ) ', NULL, NULL, 1),
(6, 'tidak disetujui', 'customerslimit', 'pengajuan limit customer terakhir tidak disetujui oleh supervisor ( kondisi yaitu limit pembelian berbeda dengan pengajuan limit pembelian berlangsung sampai adanya pengajuan ulang ) ', NULL, NULL, -1),
(7, 'diajukan', 'customerslimit', 'pengajuan limit customer sedang diajukan dan menunggu konfirmasi supervisor', NULL, NULL, 0),
(8, 'active', 'staffs', 'staff masih dinyatakan aktif dalam perusahaan\r\n', NULL, NULL, 1),
(9, 'inactive', 'staffs', 'staff dinyatakan tidak aktif lagi dalam perusahaan', NULL, NULL, -1),
(10, 'active', 'items', 'item masih diperjual-belikan didalam perusahaan', NULL, NULL, 1),
(11, 'inactive', 'items', 'item tidak lagi diperjual-belikan didalam perusahaan', NULL, NULL, -1),
(12, 'dikonfirmasi', 'returs', 'pengajuan retur telah dikonfirmasi oleh admin dan telah diproses juga:\r\ndisetujui = pemrosesan yang dilakukan adalah tukar guling atau potongan invoice\r\ntidak disetujui = pemrosesan selanjutnya yang dilakukan adalah tukar guling \r\npemrosesan ini dapat dilakukan dari sisi salesman maupun administrasi (NB: administrasi dapat melakukan kontak tersendiri pada customer untuk proses yang akan dilakukan)(NB: jika admin melakukan perubahan pada tipe retur disaat ada pengajuan retur maka tipe retur tersebut tidak dicatat pada profile customer)', NULL, NULL, 1),
(13, 'diajukan', 'returs', 'tenaga pengirim melakukan pengajuan retur barang', NULL, NULL, 0),
(14, 'active', 'orders', 'order telah dikonfirmasi dan sudah mengurangi stok', NULL, NULL, 1),
(15, 'inactive', 'orders', 'order masih merupakan sebuah draft', NULL, NULL, -1),
(16, 'active', 'events', 'event masih sedang berlangsung', NULL, NULL, 1),
(17, 'inactive', 'events', 'event tidak lagi berlangsung \r\n- event telah lewat hari berlakunya (cron)\r\n- event dinyatakan tidak berlaku oleh supervisor sendiri', NULL, NULL, -1),
(18, 'belum mulai', 'drop_events', 'event akan berlangsung', NULL, NULL, 0),
(19, 'diajukan customer', 'order_tracks', 'order dilakukan oleh customer sendiri dan menunggu salesman untuk meneruskan kepada admin', NULL, NULL, 0),
(20, 'diajukan salesman', 'order_tracks', 'order sudah diajukan oleh salesman dan menunggu konfirmasi admin', NULL, NULL, 1),
(21, 'dikonfirmasi admin', 'order_tracks', 'order sudah dikonfirmasi admin menunggu keberangkatan barang', NULL, NULL, 2),
(22, 'dalam perjalanan', 'order_tracks', 'order sudah dalam perjalanan ', NULL, NULL, 3),
(23, 'order telah sampai', 'order_tracks', 'order telah sampai dan menunggu konfirmasi admin', NULL, NULL, 4),
(24, 'order selesai', 'order_tracks', 'order telah selesai ', NULL, NULL, 5),
(25, 'order ditolak', 'order_tracks', 'order telah ditolak ', NULL, NULL, -1),
(26, 'deleted', 'events', 'event tidak lagi berlangsung dan dihapus ', NULL, NULL, -2);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
